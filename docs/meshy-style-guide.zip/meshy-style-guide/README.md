# VELSCOUR TACTICS: the Meshy style guide

This zip lets any Claude account with the Meshy MCP make new models in exactly the style of the game's 100+ Meshy models.

## Contents

- **`prompts.json`:** every prompt as data.
  - `style`: the shared look blocks.
  - `classes`, `named`, `zombies`, `summons`, `weapons` and `scenery`: one subject line per model.
  - `fitted`: the keys that wear nothing long.
  - `negative`: the negative prompt.
- **`prompt.mjs`:** builds a ready-to-paste prompt from that data. Put it in the same folder as `prompts.json`, then run:
  - `node prompt.mjs` to list every key;
  - `node prompt.mjs <key> image` for the picture prompt (the text-to-image step);
  - `node prompt.mjs <key>` for the 3D prompt (subject line plus style block);
  - `node prompt.mjs <key> 3` for a class with tier-3 armour.
- **`examples/`:** finished pictures in the house style. Match these.

## The look

The style blocks in `prompts.json` set the look:
- An original character in the ornate job-armour tradition of Final Fantasy XIV artifact gear.
- Tall, elegant, realistic proportions, about 7.5 heads.
- Intricate layered costume: engraved filigree, brocade, tooled leather, jewelled fittings.
- A bold silhouette, made by the shoulders and the headpiece.
- A grimdark palette: blackened grave steel, tarnished gold, deep wine, night indigo and bone ivory.
- Worn, battle-scarred and candle-sooted; sombre and regal, never cute or generic.
- Semi-realistic painted 3D game character, very high detail.

Write a new subject line in the same shape as the others:
- who they are, in a few words;
- their build and face;
- then each piece of costume from head to boots, naming its colours.

Name the colours from the character's own palette and keep the grimdark base around them.

## Rules, never broken

1. **No text, letters, runes, monograms, crosses, heraldic emblems or logos** on anything. The game's two powers must
   never share a symbol, so any cross shape is out, including:
   - crossing straps;
   - an X-shaped scar;
   - a compass face;
   - a ribbon tied crosswise round a parcel;
   - a faceplate with a vertical ridge through an eye slit.

   Check every picture zoomed in before 3D. Fix it by image-to-image editing ("remove X, keep everything else exactly the
   same").
2. **Fitted** (the `style.fitted` block): no cape, cloak, mantle, robe, long coat, tabard or hanging sash ends. Every
   garment ends above the knee. Long cloth looks bad in every animation.
3. **A-pose, hands open and empty.** A 3D model made from an A-pose drops held weapons anyway; weapons are separate
   models attached in the engine.
4. **A pair of a class (`_m` and `_f`): make each by text-to-image from its own prompt, never image-to-image** from the
   other. `prompt.mjs` swaps the sex words for you.
5. **Plain light grey background, one character, front view.** No frames or painted ornaments behind the figure; edit
   them out if they appear.
6. **The cost goes to the user first.** Meshy costs credits, so state the cost and wait for a yes before generating.

## The route and its parameters

| Step | Tool | Parameters | Credits |
|---|---|---|---|
| Picture | `meshy_text_to_image` | `ai_model: "nano-banana-pro"`, `pose_mode: "a-pose"`, the `image` prompt | 9 |
| Fix a detail | `meshy_image_to_image` | `nano-banana-pro`, `input_task_id` of the picture, `aspect_ratio: "3:4"`, "change only ..., keep everything else exactly the same" | 9 |
| 3D (body) | `meshy_image_to_3d` | `input_task_id` of the picture, `ai_model: "meshy-t2.5"`, `model_type: "smart-topology"`, `texture_model: "meshy-n1"`, `target_polycount: 30000`, `pose_mode: "a-pose"`, `target_formats: ["glb"]` | 15 |
| 3D (prop) | `meshy_image_to_3d` | same, without `pose_mode`, `target_polycount` 6000 to 15000 | 15 |
| Rig (bodies only) | `meshy_rig` | `input_task_id` of the 3D task, `height_meters` = the body's height (1.75 to 1.95) | 5 |
| Walk | `meshy_download_model` on the rig task (`task_type: "rigging"`) | download `basic_animations.walking_glb_url` as `<key>_v2_walk.glb` | free |

- For a scenery prop, `prompt.mjs` returns one block with the subject inside it, and the picture is made without
  `pose_mode`:
  - `aspect_ratio` 4:3 for wide things, such as a chest;
  - 3:4 for tall things, such as a gatepost or a tree.
- After rigging, the game's own Blender pipeline (`tools/blender/retarget.py`, `docs/MODELS.md` section 12) puts the
  Mixamo animation set on the rig.

## Examples

All in `examples/`:
- **The lancer** (`lancer_m`, `lancer_f`): midnight-blue and gold plate with a fin crest. This is the bar for "looks sick".
- **The slime lord** (`slime_lord_m`): armour strapped over translucent slime, with no cloth at all.
- **Named heroes:**
  - `marigold`, a fitted ranger;
  - `thordis`, a dragoon with the pale queasy face that took a second try;
  - `isabeau`, a dragoon after her background was edited clean;
  - `ingram`, an old lancer.
- **A prop** (`chest`): an iron-bound oak chest with its lid on two hinges at the back.
